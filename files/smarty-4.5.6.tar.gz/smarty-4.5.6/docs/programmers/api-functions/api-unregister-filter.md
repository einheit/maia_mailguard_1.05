unregisterFilter()

dynamically unregister a filter

Description
===========

void

unregisterFilter

string

type

string\|array

callback

Use this to dynamically unregister filters. It uses the following
parameters:

See also [`registerFilter()`](#api.register.filter).
