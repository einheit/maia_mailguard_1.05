\$trusted\_dir {#variable.trusted.dir}
==============

`$trusted_dir` is only for use when security is enabled. This is an
array of all directories that are considered trusted. Trusted
directories are where you keep php scripts that are executed directly
from the templates with
[`{insert}`](#language.function.insert.php).
